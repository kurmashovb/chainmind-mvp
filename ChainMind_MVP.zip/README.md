# ChainMind (MVP)

Децентрализованный AI-ассистент на Web3 + GPT.

## Возможности:
- Подключение через MetaMask
- Отправка вопроса в блокчейн
- Получение ответа от GPT-4o

## Установка:
1. Залей `index.html` на любой хостинг (например, GitHub Pages).
2. Разверни `ChainMind.sol` через Remix или Hardhat.
3. Укажи адрес контракта и OpenAI API ключ в `index.html`.

## Лицензия
MIT
